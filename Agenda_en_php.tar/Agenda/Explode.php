<?php


class Explode {

	private $_hour;
	private $_minute;
	private $_day;
	private $_month;
	private $_year;
    private $_dname;


	function __construct() {}


	function splitTime($time) {

		$tmp = explode(":", $time);
		$this->_hour = $tmp[0];
		$this->_minute = $tmp[1];
	}

	function splitDate($time) {

		$tmp = explode("-", $time);
		$this->_year = $tmp[0];
		$this->_month = $tmp[1];
		$this->_day = $tmp[2];
	}

	function splitActualTime($time){
        $tmp = explode(" ", $time);
        $this->_dname = $tmp[0];
		$this->_day = $tmp[1];
        $this->_month = $tmp[2];
        $this->_year = $tmp[3];

        $monthName = $tmp[2];

            if($monthname == "January") $this->_month = 1;
            if($monthName == "February")$this->_month = 2;
            if($monthName == "March")$this->_month = 3;
            if($monthName == "April")$this->_month = 4;
            if($monthName == "May")$this->_month = 5;
            if($monthName == "June")$this->_month = 6;
            if($monthName == "July")$this->_month = 7;
            if($monthName == "August")$this->_month = 8;
            if($monthName == "September")$this->_month = 9;
            if($monthName == "October")$this->_month = 10;
            if($monthName == "November")$this->_month = 11;
            if($monthName == "December")$this->_month = 12;

        $dayName = $tmp[0];

            if($dayName == "Sunday")$this->_dname = 0;
            if($dayName == "Monday") $this->_dname = 1;
            if($dayName == "Tuesday")$this->_dname = 2;
            if($dayName == "Wednesday")$this->_dname = 3;
            if($dayName == "Thursday")$this->_dname = 4;
            if($dayName == "Friday")$this->_dname = 5;
            if($dayName == "Saturday")$this->_dname = 6;


    }

    function test($tmp){

        echo $tmp;
    }

	function getHour() {
		return $this->_hour;
	}

	function getMinute() {
		return $this->_minute;
	}

	function getDay() {
		return $this->_day;
	}

	function getMonth() {
		return $this->_month;
	}

	function getYear() {
		return $this->_year;
	}

	function getdname() {
		return $this->_dname;
	}



}

    // echo "mety";
?>
