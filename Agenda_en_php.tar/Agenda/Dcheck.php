<?php

class Dcheck {

	function __construct() {}

	function is_bissextile($year) {

		if(($year % 4 == 0) && ( $year % 100 != 100 || $year % 400 == 0 )) {
			return true;
		}
		else {
			return false;
		}
	}


	function preVerify($preSelect, $month, $isBissextile) {

		$dayValue = $preSelect;
		$max = 0;
		$limit = 1;
		$month = $month -1;

		if($isBissextile) {

			if($month == 2) {					// 29 days on febroary
				$max = 29;
				if($preSelect < $limit) {
					$dayValue = $max + $preSelect;
				}
			}
			else if ($month == 1 || $month == 3 || $month == 5 || $month == 7 || $month == 8 || $month == 10 || $month == 12){
				$max = 31;
				if($preSelect < $limit) {
					$dayValue = $max + $preSelect;
				}
			}

			else {
				$max = 30;
				if($preSelect < $limit) {
					$dayValue = $max + $preSelect;
				}

			}
		}
		else {

			if($month == 2) {						// 28 days on febroary
				$max = 28;
				if($preSelect < $limit) {
					$dayValue = $max + $preSelect;
				}
			}

			else if ($month == 1 || $month == 3 || $month == 5 || $month == 7 || $month == 8 || $month == 10 || $month == 12){
				$max = 31;
				if($preSelect < $limit) {
					$dayValue = $max + $preSelect;
				}
			}
			else {
				$max = 30;
				if($preSelect < $limit) {
					$dayValue = $max + $preSelect;
				}

			}
		}

		return $dayValue;
	}

	function postVerify($postSelect, $month, $isBissextile) {

		$dayValue = $postSelect;
		$limit = 0;

		if($isBissextile) {

			if($month == 2) {					// 29 days on febroary

				$limit = 29;
				if($postSelect > $limit) {
					$dayValue = $postSelect - $limit;
				}
			}
			else if ($month == 1 || $month == 3 || $month == 5 || $month == 7 || $month == 8 || $month == 10 || $month == 12){
				$limit = 31;
				if($postSelect > $limit) {
					$dayValue = $postSelect - $limit;
				}
			}

			else {
				$limit = 30;
				if($postSelect > $limit) {
					$dayValue = $postSelect - $limit;
				}

			}
		}
		else {
			if($month == 2) {						// 28 days on febroary
				$limit = 28;
				if($postSelect > $limit) {
					$dayValue = $postSelect - $limit;
				}
			}

			else if ($month == 1 || $month == 3 || $month == 5 || $month == 7 || $month == 8 || $month == 10 || $month == 12){
				$limit = 31;
				if($postSelect > $limit) {
					$dayValue = $postSelect - $limit;
				}
			}
			else {
				$limit = 30;
				if($postSelect > $limit) {
					$dayValue = $postSelect - $limit;
				}

			}
		}
		// ...
		return $dayValue;
	}
}

?>
