<?php
    session_start();

    require_once("Explode.php");

    $dateString = date('l j F Y');
    $date = new Explode();

    $date->splitActualTime($dateString);

    $_SESSION['dname'] = $date->getdname();
    $_SESSION['day'] = $date->getDay();
    $_SESSION['month'] = $date->getMonth();
    $_SESSION['year'] = $date->getYear();

    header("Location:Board.html");
    // echo "tous les data sont prêts !";


?>
