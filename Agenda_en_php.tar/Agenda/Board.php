
<?php

    session_start();

    require_once("Dcheck.php");
    require_once("Explode.php");



	echo "<!DOCTYPE html>";
	echo "<html>";
	echo "<head>";
	echo "<meta charset=\"UTF-8\">";
	echo "<title> Table du temps </title>";
	echo "</head>";
	echo "<body style=\"background-color:gray;\" >";
	echo "<H1 align=\"center\">AGENDA</H1>";

	/*
	<p>Valeur de l'attribut "day" : ${requestScope.day} </p>
	<p>Valeur de l'attribut "day number" : ${requestScope.number} </p>
	<p>Valeur de l'attribut "$month" : ${requestScope.$month} </p>
	<p>Valeur de l'attribut "$year" : ${requestScope.$year} </p>
	*/
/*
		$day_name = 2;
		$day_number = 3;
		$month = 4;
		$year = 2024;*/

		$day_name = $_SESSION['dname'];
		$day_number = $_SESSION['day'];
		$month = $_SESSION['$month'];
		$year = $_SESSION['$year'];

/*
		$Titre = "none";
		$D_Start = "0000-00-00";
		$D_End = "0000-00-00";
		$H_begin = "00:00";
		$H_stop = "00:00";
		$rotate = "1";
		$color = "none";
		$commit = "none";*/

		$$Titre = $_GET['Title'];
		$D_Start = $_GET['Start'];
		$D_End = $_GET['End'];
		$$H_begin = $_GET['H_Start'];
		$H_stop = $_GET['H_End'];
		$rotate = $_GET['rotate'];
		$color = $_GET['color'];
		$commit = $_GET['commit'];


	echo "<a style=\"margin-left: 50q;\" href=\"AddEvent.html\">Ajout tâche</a>";
	echo "<BR><BR>";
	echo "<a style=\"margin-left: 100q;\" href=\"page1.html\">Precedent</a>";
	echo "<a style=\"margin-right: 50q;float: right;\" href=\"page2.html\">Suivant</a>";

	echo "<BR>";
echo "<table>";

	echo "<tr>";
		echo "<th style=\"width: 150cap\">  </th>";
		echo "<th style=\"width: 14%\">L</th>";
		echo "<th style=\"width: 14%\">M</th>";
		echo "<th style=\"width: 14%\">M</th>";
		echo "<th style=\"width: 14%\">J</th>";
		echo "<th style=\"width: 14%\">V</th>";
		echo "<th style=\"width: 14%\">S</th>";
		echo "<th style=\"width: 14%\">D</th>";
	echo "</tr>";

   /* *************************************************************************************************** */

    $check = new Dcheck();

    if($day_name == 1) { 								// day_of_week verification

 	$Monday = $day_number;
 	$Tuesday = $check->postVerify($day_number+1, $month, $check->is_bissextile($year));
 	$Wednesday = $check->postVerify($day_number+2, $month, $check->is_bissextile($year));
 	$Thursday = $check->postVerify($day_number+3, $month, $check->is_bissextile($year));
 	$Friday = $check->postVerify($day_number+4, $month, $check->is_bissextile($year));
 	$Saturday = $check->postVerify($day_number+5, $month, $check->is_bissextile($year));
 	$Sunday = $check->postVerify($day_number+6, $month, $check->is_bissextile($year));

    $line = "<tr>".
                    "<td><span > </span></td>".
                    "<td><span class=\"jour-actuel\">".$Monday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Tuesday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Wednesday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Thursday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Friday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Saturday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Sunday."</span></td>".
            "</tr>";


   }	elseif($day_name == 2) {
	  	$Monday = $check->preVerify($day_number-1, $month, $check->is_bissextile($year));
	 	$Tuesday = $day_number;
	 	$Wednesday = $check->postVerify($day_number+1, $month, $check->is_bissextile($year));
	 	$Thursday = $check->postVerify($day_number+2, $month, $check->is_bissextile($year));
	 	$Friday = $check->postVerify($day_number+3, $month, $check->is_bissextile($year));
	 	$Saturday = $check->postVerify($day_number+4, $month, $check->is_bissextile($year));
	 	$Sunday = $check->postVerify($day_number+5, $month, $check->is_bissextile($year));


    $line = "<tr>".
                    "<td><span > </span></td>".
                    "<td><span class=\"numero-jour\">".$Monday."</span></td>".
                    "<td><span class=\"jour-actuel\">".$Tuesday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Wednesday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Thursday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Friday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Saturday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Sunday."</span></td>".
            "</tr>";

   }   elseif($day_name == 3) {
	  	$Monday = $check->preVerify($day_number-2, $month, $check->is_bissextile($year));
	 	$Tuesday = $check->preVerify($day_number-1, $month, $check->is_bissextile($year));
	 	$Wednesday = $day_number;
	 	$Thursday = $check->postVerify($day_number+1, $month, $check->is_bissextile($year));
	 	$Friday = $check->postVerify($day_number+2, $month, $check->is_bissextile($year));
	 	$Saturday = $check->postVerify($day_number+3, $month, $check->is_bissextile($year));
	 	$Sunday = $check->postVerify($day_number+4, $month, $check->is_bissextile($year));



    $line = "<tr>".
                    "<td><span > </span></td>".
                    "<td><span class=\"numero-jour\">".$Monday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Tuesday."</span></td>".
                    "<td><span class=\"jour-actuel\">".$Wednesday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Thursday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Friday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Saturday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Sunday."</span></td>".
            "</tr>";

  } elseif($day_name == 4) {
	  	$Monday = $check->preVerify($day_number-3, $month, $check->is_bissextile($year));
	 	$Tuesday = $check->preVerify($day_number-2, $month, $check->is_bissextile($year));
	 	$Wednesday =  $check->preVerify($day_number-1, $month, $check->is_bissextile($year));
	 	$Thursday = $day_number;
	 	$Friday = $check->postVerify($day_number+1, $month, $check->is_bissextile($year));
	 	$Saturday = $check->postVerify($day_number+2, $month, $check->is_bissextile($year));
	 	$Sunday = $check->postVerify($day_number+3, $month, $check->is_bissextile($year));


    $line = "<tr>".
                    "<td><span > </span></td>".
                    "<td><span class=\"numero-jour\">".$Monday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Tuesday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Wednesday."</span></td>".
                    "<td><span class=\"jour-actuel\">".$Thursday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Friday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Saturday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Sunday."</span></td>".
            "</tr>";

   } elseif($day_name == 5) {
	 	$Monday = $check->preVerify($day_number-4, $month, $check->is_bissextile($year));
	 	$Tuesday = $check->preVerify($day_number-3, $month, $check->is_bissextile($year));
	 	$Wednesday =  $check->preVerify($day_number-2, $month, $check->is_bissextile($year));
	 	$Thursday =  $check->preVerify($day_number-1, $month, $check->is_bissextile($year));
	 	$Friday = $day_number;
	 	$Saturday = $check->postVerify($day_number+1, $month, $check->is_bissextile($year));
	 	$Sunday = $check->postVerify($day_number+2, $month, $check->is_bissextile($year));

    $line = "<tr>".
                    "<td><span > </span></td>".
                    "<td><span class=\"numero-jour\">".$Monday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Tuesday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Wednesday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Thursday."</span></td>".
                    "<td><span class=\"jour-actuel\">".$Friday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Saturday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Sunday."</span></td>".
            "</tr>";

   } elseif($day_name == 6) {
	  	$Monday = $check->preVerify($day_number-5, $month, $check->is_bissextile($year));
	 	$Tuesday = $check->preVerify($day_number-4, $month, $check->is_bissextile($year));
	 	$Wednesday =  $check->preVerify($day_number-3, $month, $check->is_bissextile($year));
	 	$Thursday =  $check->preVerify($day_number-2, $month, $check->is_bissextile($year));
	 	$Friday = $check->preVerify($day_number-1, $month, $check->is_bissextile($year));
	 	$Saturday = $day_number;
	 	$Sunday = $check->postVerify($day_number+1, $month, $check->is_bissextile($year));

    $line = "<tr>".
                    "<td><span > </span></td>".
                    "<td><span class=\"numero-jour\">".$Monday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Tuesday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Wednesday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Thursday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Friday."</span></td>".
                    "<td><span class=\"jour-actuel\">".$Saturday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Sunday."</span></td>".
            "</tr>";

   } elseif($day_name == 0){
	  	$Monday = $check->preVerify($day_number-6, $month, $check->is_bissextile($year));
	 	$Tuesday = $check->preVerify($day_number-5, $month, $check->is_bissextile($year));
	 	$Wednesday =  $check->preVerify($day_number-4, $month, $check->is_bissextile($year));
	 	$Thursday =  $check->preVerify($day_number-3, $month, $check->is_bissextile($year));
	 	$Friday = $check->preVerify($day_number-2, $month, $check->is_bissextile($year));
	 	$Saturday = $check->preVerify($day_number-1, $month, $check->is_bissextile($year));
	 	$Sunday = $day_number;

    $line = "<tr>".
                    "<td><span > </span></td>".
                    "<td><span class=\"numero-jour\">".$Monday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Tuesday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Wednesday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Thursday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Friday."</span></td>".
                    "<td><span class=\"numero-jour\">".$Saturday."</span></td>".
                    "<td><span class=\"jour-actuel\">".$Sunday."</span></td>".
            "</tr>";

   } else {
  		echo "erreur: ce jour n'existe pas";
   }

    echo $line;

 /* *************************************************************************************************** */


 	$expStart = new Explode();
 	$expEnd = new Explode();

 	$expStart->splitTime($H_begin);
	$expStart->splitDate($D_Start);
	$expEnd->splitTime($H_stop);
	$expEnd->splitDate($D_End);


 	$hourStart = $expStart->getHour(); $hourEnd = $expEnd->getHour();
 	$minuteStart = $expStart->getMinute(); $minuteEnd = $expEnd->getMinute();
 	$dayStart = $expStart->getDay(); $dayEnd = $expEnd->getDay();
 	$monthStart = $expStart->getMonth(); $monthEnd = $expEnd->getMonth();
 	$yearStart = $expStart->getYear(); $yearEnd = $expEnd->getYear();



	for ($i= 0; $i< 23; $i++) {										//   from hour
		$j = $i + 1;
		echo "<tr>";
				 echo "<td>".$i.":00 - ".$j.":00 "."</td>";

			    if($i >= $hourStart && $i < $hourEnd){													// L'heure est definit ligne par ligne

					if($Monday == $dayStart ){
						echo "<td style=\"background-color:".$color.";\"></td>";
					}else {
						echo "<td></td>";
					}
					if($Tuesday == $dayStart){
						echo "<td style=\"background-color:".$color.";\"></td>";
					}else {
						echo "<td></td>";
					}
					if($Wednesday == $dayStart){
						echo "<td style=\"background-color:".$color.";\"></td>";
					}else {
						echo "<td></td>";
					}
					if($Thursday == $dayStart){
						echo "<td style=\"background-color:".$color.";\"></td>";
					}else {
						echo "<td></td>";
					}

					if($Friday == $dayStart){
						echo "<td style=\"background-color:".$color.";\"></td>";
					}else {
						echo "<td></td>";
					}
					if($Saturday == $dayStart){
						echo "<td style=\"background-color:".$color.";\"></td>";
					}else {
						echo "<td></td>";
					}
					if($Sunday == $dayStart){
						echo "<td style=\"background-color:".$color.";\"></td>";

					}else {
						echo "<td></td>";
					}



			    }else{
			    	for($d = 0; $d < 7; $d++) {
			    		echo "<td></td>";
			    	}
			    }


		  echo "</tr>";

    }

    echo "<tr><td> 23:00 - 00:00</td>";							//   from hour

		if($i >= $hourStart && $i < $hourEnd){													// L'heure est definit ligne par ligne

			if($Monday == $dayStart ){
				echo "<td style=\"background-color:".$color.";\"></td>";
			}else {
				echo "<td></td>";
			}
			if($Tuesday == $dayStart){
				echo "<td style=\"background-color:".$color.";\"></td>";
			}else {
				echo "<td></td>";
			}
			if($Wednesday == $dayStart){
				echo "<td style=\"background-color:".$color.";\"></td>";
			}else {
				echo "<td></td>";
			}
			if($Thursday == $dayStart){
				echo "<td style=\"background-color:".$color.";\"></td>";
			}else {
				echo "<td></td>";
			}

			if($Friday == $dayStart){
				echo "<td style=\"background-color:".$color.";\"></td>";
			}else {
				echo "<td></td>";
			}
			if($Saturday == $dayStart){
				echo "<td style=\"background-color:".$color.";\"></td>";
			}else {
				echo "<td></td>";
			}
			if($Sunday == $dayStart){
				echo "<td style=\"background-color:".$color.";\"></td>";

			}else {
				echo "<td></td>";
			}



		}else{
			for($d = 0; $d < 7; $d++) { 							//   from DAY
	    		echo "<td></td>";
			}
		}

	echo "</tr>";


echo "</table>";
echo "</body>";
echo "</html>";

?>

<style>
	table {
		margin-top: 50q;
	  width: 100%;
	  border-collapse: collapse;
}

th, td {

  border: 1px solid rgb(98, 160, 234);
  padding: 5px;
  text-align: center;
  text-align: center;
  height: 20px;

}

th {
	color: white;
}


.heure {
  width: 100px;
}

.numero-jour {
	text-align: center;
	margin: 0 auto;
  	display: inline-block;
  	width: 20px;
  	height: 20px;
  	border-radius: 50%;
  	text-align: center;
  	background-color: black;
  	color: white;

}

.jour-actuel {
	text-align: center;
	margin: 0 auto;
  	display: inline-block;
 	width: 20px;
  	height: 20px;
  	border-radius: 50%;
  	text-align: center;
  	background-color: purple;
  	color: white;
}

</style>

